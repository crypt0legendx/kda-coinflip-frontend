# KadenaKode

KadenaKode is a simple UI for sending transactions to the Kadena Blockchain using x wallet or chainweaver/zelcore.

Type in your pact code.  
Add env variables using the EnvData area.  
Run the code locally or send it as a transaction to the blockchain.  
