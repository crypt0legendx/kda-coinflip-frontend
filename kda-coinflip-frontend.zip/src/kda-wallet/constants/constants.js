export const X_WALLET = 'X_WALLET';
export const ZELCORE = 'ZELCORE';

export const NEW_TX = 'new_tx';